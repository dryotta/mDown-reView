This is a sample ZIP archive used by mdownreview's BinaryPlaceholder fixture.
